Name of Program: bin.cpp

Author: Chinmay Wadgaonkar

Compilation: Run command "g++ bin.cpp" in terminal

Execution: Run command "a.out" in terminal

Output: In terminal. Tells you how many bins were used for each algorithm.


Compilation for comparison: Run command "g++ compare.cpp" in terminal

Output: Compares the two algorithms, firstFit and firstFitDec and shows which one is more efficient for bin usage


Compilation for extra credit: Run command "g++ binIP.cpp"

Output: 3 files called 'testcase1.ltx', 'testcase2.ltx', 'testcase3.ltx'. These files can be imported into LINDO to run integer programming and get the minimum number of bins used.
