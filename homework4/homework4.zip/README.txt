Name of Program: last2start.cpp
Author: Chinmay Wadgaonkar

Compilation: Run command "g++ last2start.cpp" in terminal
Execution: Run command "a.out" in terminal
Output File: Activities.txt
