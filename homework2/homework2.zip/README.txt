Name of Program: stoogesort.cpp
Author: Chinmay Wadgaonkar

Compilation: Run command "g++ stoogesort.cpp" in terminal
Execution: Run command "a.out" in terminal
Output File: sortedStooge.txt
