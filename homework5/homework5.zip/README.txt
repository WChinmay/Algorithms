Name of Program: wrestlers.cpp

Author: Chinmay Wadgaonkar

Compilation: Run command "g++ wrestlers.cpp" in terminal

Execution: Run command "a.out <input_text_file>" in terminal
           Example: "a.out wrestler.txt"

Output: Terminal
